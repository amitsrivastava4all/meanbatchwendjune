const UserSc = require('../models/userschema');
const encrypt = require('../utils/encrypt');
const unique = require('../utils/unique');
const userOperations = {
    add(userObject){
        userObject.password= encrypt.generateHash(userObject.password);
        userObject.genid = unique();
        const promise = UserSc.create(userObject);
        return promise;
        // let userSchema = new UserSc(userObject);
        // let promise = userSchema.save();
        // return promise;
        // UserSchema.create(userObject,(err)=>{
        //         if(err){

        //         }
        //         else{

        //         }
        // })
    },
    delete(){

    },
    search(userObject,response){
        
       // UserSc.findOne({'userid':userObject.userid,'password':userObject.password},(err,doc)=>{
        UserSc.findOne({'userid':userObject.userid},(err,doc)=>{
            if(err){
                response.json({'message':'Error In DB During Login Operation','error':err});
            }
            else{
                if(doc){
                    if(encrypt.compareHash(userObject.password,doc.password)){
                        response.json({'message':'Welcome','userid':doc.userid}); 
                    }
                    else{
                        response.json({'message':'Invalid Userid or Password'});
                    }
                    
                   
                }
                else{
                    response.json({'message':'Invalid Userid or Password'});
                }
            }
        });
    },
    update(){

    }
}
module.exports = userOperations;