const mongoose = require('../db/connection');
const UserSchema = new mongoose.Schema({
    'userid':{type:String,required:true,unique:true},
    'password':{type:String, required:true},
    'genid':{type:String},
    'email':{type:String,required:true},
    'isverified':{type:String,maxlength:1,minlength:1,default:'N'},
    'name':{type:String,required:true, maxlength:20,minlength:3}
});
const userModel = mongoose.model('users',UserSchema);
module.exports = userModel;