const express = require('express');
const userRoutes = express.Router();
const winston = require('../utils/logger');
const sendMail = require('../utils/mail');

userRoutes.get('/verify/:verificationid',(req,res)=>{
  var id = req.params.verificationid;
  const userOperations = require('../helpers/useroperations');
  userOperations.isVerified(id, res);
  //console.log('Verification Id ',req.params.verificationid);
});
userRoutes.post('/loginuser',(req,res)=>{
  const userOperations = require("../helpers/useroperations");
  const userObject = {'userid':req.body.userid,'password':req.body.pwd};
  userOperations.search(userObject,res);
});
userRoutes.post('/reg',(req, res)=>{
  winston.debug('Inside Reg ');
  console.log('REG POST ',req.body);
  const userOperations = require("../helpers/useroperations");
  let pr = userOperations.add({'userid':req.body.userid,'password':req.body.pwd,'name':'Amit','email':req.body.email});
  pr.then(data=>{
   // res.send('Register Successfully');
    console.log('Inside Reg ',data);
    const url = `http://localhost:1234/verify/${data.genid}`;
    res.json({'message':'Register SuccessFully'});
    //sendMail(data.userid,url,data.email, res);
  }).catch(err=>{
    console.log('Error During Register ',err);
    res.send('Error During Register ');
  })

  // if(req.body.userid==req.body.pwd){
  //     const menuObject = require('../models/menu');
  //     res.render('dashboard',{'username':req.body.userid, 'menus':menuObject['menus']});
  //    // const path = require('path');
      
  //     //var fullPath = path.join(path.normalize(__dirname+"/.."),'/public/dashboard.html');
  //     //console.log('FullPath is ',fullPath);
  //   //  res.sendFile(fullPath);
  //     //res.send('Welcome '+req.body.userid);
  // }
  // else{
  // res.send('Invalid Userid or Password ');
  // }
  });

userRoutes.post('/login',(req, res)=>{
    console.log('POST ',req.body);
    if(req.body.userid==req.body.pwd){
        const menuObject = require('../models/menu');
        res.render('dashboard',{'username':req.body.userid, 'menus':menuObject['menus']});
       // const path = require('path');
        
        //var fullPath = path.join(path.normalize(__dirname+"/.."),'/public/dashboard.html');
        //console.log('FullPath is ',fullPath);
      //  res.sendFile(fullPath);
        //res.send('Welcome '+req.body.userid);
    }
    else{
    res.send('Invalid Userid or Password ');
    }
    });
module.exports = userRoutes;    