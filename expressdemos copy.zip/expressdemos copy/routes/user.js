const express = require('express');
const userRoutes = express.Router();
userRoutes.post('/loginuser',(req,res)=>{
  const userOperations = require("../helpers/useroperations");
  const userObject = {'userid':req.body.userid,'password':req.body.pwd};
  userOperations.search(userObject,res);
});
userRoutes.post('/reg',(req, res)=>{
  console.log('REG POST ',req.body);
  const userOperations = require("../helpers/useroperations");
  let pr = userOperations.add({'userid':req.body.userid,'password':req.body.pwd,'name':'Amit','email':req.body.email});
  pr.then(data=>{
    res.send('Register Successfully');
  }).catch(err=>{
    console.log('Error During Register ',err);
    res.send('Error During Register ');
  })

  // if(req.body.userid==req.body.pwd){
  //     const menuObject = require('../models/menu');
  //     res.render('dashboard',{'username':req.body.userid, 'menus':menuObject['menus']});
  //    // const path = require('path');
      
  //     //var fullPath = path.join(path.normalize(__dirname+"/.."),'/public/dashboard.html');
  //     //console.log('FullPath is ',fullPath);
  //   //  res.sendFile(fullPath);
  //     //res.send('Welcome '+req.body.userid);
  // }
  // else{
  // res.send('Invalid Userid or Password ');
  // }
  });

userRoutes.post('/login',(req, res)=>{
    console.log('POST ',req.body);
    if(req.body.userid==req.body.pwd){
        const menuObject = require('../models/menu');
        res.render('dashboard',{'username':req.body.userid, 'menus':menuObject['menus']});
       // const path = require('path');
        
        //var fullPath = path.join(path.normalize(__dirname+"/.."),'/public/dashboard.html');
        //console.log('FullPath is ',fullPath);
      //  res.sendFile(fullPath);
        //res.send('Welcome '+req.body.userid);
    }
    else{
    res.send('Invalid Userid or Password ');
    }
    });
module.exports = userRoutes;    