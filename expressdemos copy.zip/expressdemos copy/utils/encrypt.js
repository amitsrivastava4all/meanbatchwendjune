const bcrypt = require('bcrypt');
const encrypt = {
    salt:10,
    generateHash(plainPassword){
        let hash = bcrypt.hashSync(plainPassword,this.salt);
        return hash;
    },
    compareHash(plainPassword, dbPassword){
        return bcrypt.compareSync(plainPassword,dbPassword)
    }
}
module.exports = encrypt;