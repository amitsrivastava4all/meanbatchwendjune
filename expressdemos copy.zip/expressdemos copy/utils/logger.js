const winston = require('winston');
 
const customFormat = winston.format.printf(({ level, message, label, timestamp }) => {
    return `${timestamp} [${label}] ${level}: ${message}`;
  });

const logger = winston.createLogger({
    level: 'info',
   format: winston.format.combine(winston.format.label({ label: 'TCS' }), winston.format.timestamp(),customFormat),
   transports: [
    
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log', level:'debug' })
   ]
   

});

 
module.exports = logger;