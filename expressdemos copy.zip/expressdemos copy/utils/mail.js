const nodemailer = require('nodemailer');
const verification = require('../utils/templates/verification');

function sendMail(userid, link, email, res){
    nodemailer.createTestAccount((err, account) => {
        // Specify GMAIL Account
        let transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
            user: 'yourgmailid@gmail.com',
            pass: 'yourpassword'
        }
        });

// Specify Subject Sender , Rec
let mailOptions = {
    from: 'yourgmailid@gmail.com', // sender address
    to: email, // list of receivers
    subject: 'Hello  '+userid+' U Register SuccessFully....', // Subject line
    //text: 'This is Test of Plain Text '+userid, // plain text body
    html: verification(userid, link) // html body
};
// Send the Mail
transporter.sendMail(mailOptions, (error, info) => {
    if(error){
res.json({'message':'Error During Mail Send'});
console.log('Mail Send Error ',error);
    }
    else{
  res.json({'message':'Verification Link has been send to Your Mail Id '+email})      
   
}
});
});
}
module.exports = sendMail;
