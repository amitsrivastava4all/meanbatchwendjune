const nodemailer = require('nodemailer');
function configUserAccount(){
    nodemailer.createTestAccount((err, account) => {
        // Specify GMAIL Account
        let transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
            user: 'YourGmailUserid@gmail.com',
            pass: 'GMAIL PASSWORD'
        }
        });
}
// Specify Subject Sender , Rec
let mailOptions = {
    from: '', // sender address
    to: '', // list of receivers
    subject: 'Hello  '+userid+' U Register SuccessFully....', // Subject line
    text: 'This is Test of Plain Text '+userid, // plain text body
    html: 'This is Test of HTML '+userid // html body
};
// Send the Mail
transporter.sendMail(mailOptions, (error, info) => {
    if(error){

    }
    else{
        
    }
}
}