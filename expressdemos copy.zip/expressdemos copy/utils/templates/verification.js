function verificationContent(userid,link){
    let message = `<h1>Congrats ${userid} You have been registered in this account , Please click on this link to verify your account</h1>
    <a href='${link}'>Verify Your Account </a>
    `;
    return message;
}
module.exports = verificationContent;