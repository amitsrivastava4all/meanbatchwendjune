const unique = require('short-uuid');
function generateUnique(){
    return  unique.generate();
}
module.exports = generateUnique;