const mongoose = require('mongoose');
const winston = require('../utils/logger');
var db = mongoose.connect('mongodb+srv://amit:amit123@passportdemo-6ulmm.mongodb.net/test?retryWrites=true&w=majority',{ useUnifiedTopology: true },function(err){
//var db = mongoose.connect('mongodb://localhost:27017/onlineshoppingdb2019',{poolSize:10, reconnectTries: Number.MAX_VALUE,reconnectInterval: 500},function(err){
    if(err){
        winston.error('Connection Error '+err);
        console.log("Can't Connect to the database ",err);
    }
    else{
        console.log('Connection Created...');
    }
});
// db.once('open',()=>{
//     console.log('Connection Open');
// });
module.exports = mongoose;