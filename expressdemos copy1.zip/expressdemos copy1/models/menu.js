const menus = {
    "menus":[
        {name:'Orders',link:'orders'},
        {name:'Products',link:'products'},
        {name:'Customers',link:'customers'}
    ]
};
module.exports = menus;