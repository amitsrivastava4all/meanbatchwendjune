const job = require('cron').CronJob;
new job('* * * * * *', function() {
    // Call Mail , SMS, Backup Code
    console.log('You will see this message every second');
  }, null, true, '');
