const mongoose = require('mongoose');
var db = mongoose.connect('mongodb://localhost:27017/onlineshoppingdb2019',{poolSize:10, reconnectTries: Number.MAX_VALUE,reconnectInterval: 500},function(err){
    if(err){
        console.log("Can't Connect to the database");
    }
    else{
        console.log('Connection Created...');
    }
});
// db.once('open',()=>{
//     console.log('Connection Open');
// });
module.exports = mongoose;