const UserSc = require('../models/userschema');
const userOperations = {
    add(userObject){
        const promise = UserSc.create(userObject);
        return promise;
        // let userSchema = new UserSc(userObject);
        // let promise = userSchema.save();
        // return promise;
        // UserSchema.create(userObject,(err)=>{
        //         if(err){

        //         }
        //         else{

        //         }
        // })
    },
    delete(){

    },
    search(){

    },
    update(){

    }
}
module.exports = userOperations;