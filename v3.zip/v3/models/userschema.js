const mongoose = require('../db/connection');
const UserSchema = new mongoose.Schema({
    'userid':{type:String,required:true,unique:true},
    'password':{type:String, required:true},
    'name':{type:String,required:true, maxlength:20,minlength:3}
});
const userModel = mongoose.model('users',UserSchema);
module.exports = userModel;